package JustPay.JustPay;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AppTest {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
		WebElement searchBox = driver.findElement(By.name("q"));
		searchBox.sendKeys("iphone 15");
		searchBox.submit();

		String mainPage = driver.getWindowHandle();
		System.out.println("Main page=" + mainPage);

		driver.findElement(By.xpath("//div[@class='KzDlHZ']")).click();

		Set<String> allPages = driver.getWindowHandles();
		for (String page : allPages) {
			if (!page.equals(mainPage)) {
				driver.switchTo().window(page);
				break;
			}
		}
		System.out.println(driver.getCurrentUrl());
		List<WebElement> products = driver.findElements(By.className("_21Ahn-"));
		System.out.println(products.size());
		for (WebElement product : products) {
			System.out.println(product.getText());
		}
		driver.findElement(By.xpath("//button[normalize-space()='Add to cart']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[2]/div/div/div[1]/div/div[4]/div/form/button"))
				.click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"//*[@id='container']/div/div[2]/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[1]/input"))
				.click();
		driver.findElement(By.xpath(
				"//*[@id='container']/div/div[2]/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[1]/input"))
				.sendKeys("7872408552");
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[3]/button"))
				.click();
		Thread.sleep(15000);
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[2]/input"))
				.click();
		Thread.sleep(15000);
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[1]/div/div/div/div/div[1]/div/form/div[4]/button"))
				.click();
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"ADD14274535158691943\"]/button")).click();
		Thread.sleep(5000);
		driver.findElement(
				By.xpath("//*[@id=\"container\"]/div/div[2]/div/div[1]/div[3]/div/div/div/div[1]/div/button")).click();

		driver.findElement(By.xpath("//*[@id=\"to-payment\"]/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div/div/button")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[3]/div[2]/div/div/div[2]/span"))
				.click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");

		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[1]/div/div/input"))
				.sendKeys("4242424242424242");

		Select dropdown = new Select(driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[2]/span[2]/div[1]/select")));

		dropdown.selectByIndex(1);

		Select dropdown2= new Select(driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[2]/span[2]/div[2]/select")));

		dropdown2.selectByIndex(4);
		
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[3]/div/div/input"))
				.click();
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[3]/div/div/input"))
				.sendKeys("123");
		driver.findElement(By.xpath(
				"//*[@id=\"container\"]/div/div[2]/div/div[1]/div[4]/div/div/div[3]/div/label[2]/div[2]/div/div/div[3]/form/div[4]/button"))
				.click();
		
	
		driver.findElement(By.xpath("//[contains(text(),'Not a vaild card number')]"));
		
	
	}

}
